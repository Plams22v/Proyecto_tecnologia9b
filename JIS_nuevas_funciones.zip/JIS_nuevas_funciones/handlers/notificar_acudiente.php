<?php
/**
 * ============================================================
 *  notificar_acudiente.php
 *  Envía correo al acudiente cuando se registra la salida
 *  de un estudiante.
 *
 *  DEPENDENCIA: PHPMailer (instalar con Composer)
 *    composer require phpmailer/phpmailer
 *
 *  CONFIGURACIÓN: editar la sección "SMTP CONFIG" abajo
 * ============================================================
 */

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Ajusta la ruta si usas Composer en otro directorio
require_once __DIR__ . '/../vendor/autoload.php';

/**
 * enviarNotificacionSalida()
 *
 * @param array $estudiante  Fila de BD con datos del estudiante
 * @param array $acudiente   Fila de BD con datos del acudiente
 * @param string $motivo     Motivo de la salida
 * @param string $fecha      Fecha/hora formateada de la salida
 * @return bool              true si el correo se envió, false si hubo error
 */
function enviarNotificacionSalida(array $estudiante, array $acudiente, string $motivo, string $fecha): bool
{
    // ── SMTP CONFIG ───────────────────────────────────────────
    // Cambia estos valores por los de tu servidor de correo real.
    // Con Gmail activa "Contraseñas de aplicación" en tu cuenta.
    $smtp_host     = 'smtp.gmail.com';
    $smtp_usuario  = 'correo_del_colegio@gmail.com';   // ← tu correo
    $smtp_password = 'tu_contrasena_de_aplicacion';    // ← contraseña app
    $smtp_puerto   = 587;
    $remitente     = 'correo_del_colegio@gmail.com';
    $nombre_rem    = 'Colegio COSFA – Recepción';
    // ─────────────────────────────────────────────────────────

    $destinatario = $acudiente['email_acudiente'] ?? '';
    if (empty($destinatario)) {
        // El acudiente no tiene email registrado → omitir sin error
        return false;
    }

    $nombre_est  = htmlspecialchars($estudiante['prim_nombre'] . ' ' . $estudiante['prim_apellido']);
    $grado_est   = htmlspecialchars($estudiante['grado']);
    $nom_acud    = htmlspecialchars($acudiente['prim_nombre'] . ' ' . $acudiente['prim_apellido']);
    $motivo_html = nl2br(htmlspecialchars($motivo));

    // ── Cuerpo HTML del correo ────────────────────────────────
    $cuerpo = "
    <!DOCTYPE html>
    <html lang='es'>
    <head><meta charset='UTF-8'></head>
    <body style='font-family:Inter,Arial,sans-serif; background:#f8fafc; padding:0; margin:0;'>
      <table width='100%' cellpadding='0' cellspacing='0' style='background:#f8fafc; padding:30px 0;'>
        <tr><td align='center'>
          <table width='580' cellpadding='0' cellspacing='0'
                 style='background:#ffffff; border-radius:12px;
                        box-shadow:0 4px 20px rgba(0,0,0,0.08); overflow:hidden;'>

            <!-- Cabecera verde -->
            <tr>
              <td style='background:linear-gradient(135deg,#145c32,#2d7a4d);
                         padding:28px 32px; color:#ffffff;'>
                <h1 style='margin:0; font-size:22px; font-weight:700;'>
                  🏫 Colegio San Francisco de Asís
                </h1>
                <p style='margin:6px 0 0; opacity:.85; font-size:14px;'>
                  Sistema de Recepción JIS – Notificación automática
                </p>
              </td>
            </tr>

            <!-- Cuerpo -->
            <tr>
              <td style='padding:32px;'>
                <p style='margin:0 0 16px; font-size:16px; color:#1e293b;'>
                  Estimado/a <strong>{$nom_acud}</strong>,
                </p>
                <p style='margin:0 0 24px; font-size:15px; color:#475569;'>
                  Le informamos que su estudiante ha sido autorizado/a para salir
                  de las instalaciones del colegio.
                </p>

                <!-- Tarjeta info -->
                <table width='100%' cellpadding='0' cellspacing='0'
                       style='background:#f0fdf4; border-left:4px solid #2d7a4d;
                              border-radius:8px; padding:0; margin-bottom:24px;'>
                  <tr>
                    <td style='padding:20px 24px;'>
                      <table width='100%'>
                        <tr>
                          <td style='padding:6px 0; color:#64748b; font-size:13px; width:150px;'>
                            👤 Estudiante
                          </td>
                          <td style='padding:6px 0; font-weight:600; color:#1e293b;'>
                            {$nombre_est}
                          </td>
                        </tr>
                        <tr>
                          <td style='padding:6px 0; color:#64748b; font-size:13px;'>🎓 Grado</td>
                          <td style='padding:6px 0; font-weight:600; color:#1e293b;'>{$grado_est}</td>
                        </tr>
                        <tr>
                          <td style='padding:6px 0; color:#64748b; font-size:13px;'>🕐 Fecha/Hora</td>
                          <td style='padding:6px 0; font-weight:600; color:#1e293b;'>{$fecha}</td>
                        </tr>
                        <tr>
                          <td style='padding:6px 0; color:#64748b; font-size:13px;
                                     vertical-align:top;'>📋 Motivo</td>
                          <td style='padding:6px 0; color:#1e293b;'>{$motivo_html}</td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                </table>

                <p style='font-size:13px; color:#94a3b8; margin:0;'>
                  Este es un mensaje automático generado por el sistema JIS.
                  Si tiene dudas comuníquese con la recepción del colegio.
                </p>
              </td>
            </tr>

            <!-- Pie -->
            <tr>
              <td style='background:#f8fafc; border-top:1px solid #e2e8f0;
                         padding:16px 32px; text-align:center;
                         font-size:12px; color:#94a3b8;'>
                © " . date('Y') . " Colegio San Francisco de Asís · Recepción Digital COSFA
              </td>
            </tr>

          </table>
        </td></tr>
      </table>
    </body>
    </html>
    ";

    // ── Envío con PHPMailer ───────────────────────────────────
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = $smtp_host;
        $mail->SMTPAuth   = true;
        $mail->Username   = $smtp_usuario;
        $mail->Password   = $smtp_password;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = $smtp_puerto;
        $mail->CharSet    = 'UTF-8';

        $mail->setFrom($remitente, $nombre_rem);
        $mail->addAddress($destinatario, $nom_acud);

        $mail->isHTML(true);
        $mail->Subject = "🚨 Salida autorizada: {$nombre_est} – " . date('d/m/Y H:i');
        $mail->Body    = $cuerpo;
        $mail->AltBody = "Salida autorizada para {$nombre_est} ({$grado_est}). Motivo: {$motivo}. Fecha: {$fecha}.";

        $mail->send();
        return true;

    } catch (Exception $e) {
        // Registrar error en log pero no detener el flujo principal
        error_log("[JIS-EMAIL] Error al enviar notificación: " . $mail->ErrorInfo);
        return false;
    }
}
?>
