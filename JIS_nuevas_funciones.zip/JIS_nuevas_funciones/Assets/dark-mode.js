/**
 * ============================================================
 *  dark-mode.js  –  🎁 Modo Oscuro con persistencia en cookie
 *  Ubicación: JIS/Assets/dark-mode.js
 *
 *  USO: Agregar en CUALQUIER página del sistema:
 *    <script src="../Assets/dark-mode.js"></script>
 *    (Antes del </body>)
 *
 *  También añade automáticamente el botón flotante de toggle.
 * ============================================================
 */

(function () {
  'use strict';

  // ── CSS del modo oscuro ────────────────────────────────────
  const CSS_DARK = `
    body, html {
      background-color: #0f172a !important;
      color: #e2e8f0 !important;
    }
    .sidebar, [style*="background: linear-gradient(180deg,#145c32"],
    [style*="background:linear-gradient(180deg,#145c32"] {
      background: linear-gradient(180deg, #0d3320, #082416) !important;
    }
    .card, .modal-content, .offcanvas, .offcanvas-body,
    .result-card, .cal-day, .stat-chip, table.table {
      background-color: #1e293b !important;
      border-color: #334155 !important;
      color: #e2e8f0 !important;
    }
    .header-panel, .page-header {
      background-color: #1e293b !important;
      border-color: #334155 !important;
    }
    .table-bordered td, .table-bordered th { border-color: #334155 !important; }
    .form-control, .form-select, input, select, textarea {
      background-color: #0f172a !important;
      color: #e2e8f0 !important;
      border-color: #334155 !important;
    }
    .form-control::placeholder { color: #64748b !important; }
    .text-muted { color: #94a3b8 !important; }
    .bg-white, .bg-light { background-color: #1e293b !important; }
    .dropdown-menu { background-color: #1e293b !important; border-color: #334155 !important; }
    .dropdown-item { color: #e2e8f0 !important; }
    .dropdown-item:hover { background-color: #334155 !important; }
    .modal-header { border-color: #334155 !important; }
    .modal-footer { border-color: #334155 !important; background-color: #1e293b !important; }
    .alert { background-color: #1e293b !important; }
    .list-group-item { background-color: #1e293b !important; border-color: #334155 !important; color: #e2e8f0 !important; }
    .nav-link:not(.active):not(.btn) { color: #94a3b8 !important; }
    .search-bar { background: #1e293b !important; }
    .search-bar input { background: #1e293b !important; color: #e2e8f0 !important; }
    .tipo-card { background: #1e293b !important; border-color: #334155 !important; }
    .tipo-card span { color: #cbd5e1 !important; }
    .cal-day { background: #1e293b !important; border-color: #334155 !important; }
    .cal-day.hoy { background: #0f2d1f !important; }
    .num-dia { color: #94a3b8 !important; }
    .tabla-reporte tbody tr:hover { background: #1e3a50 !important; }
    .card-nav { background: #1e293b !important; border-color: #334155 !important; }
    .card-title-nav { color: #cbd5e1 !important; }

    /* Scrollbar oscura */
    ::-webkit-scrollbar { width: 8px; }
    ::-webkit-scrollbar-track { background: #0f172a; }
    ::-webkit-scrollbar-thumb { background: #334155; border-radius: 4px; }
    ::-webkit-scrollbar-thumb:hover { background: #2d7a4d; }
  `;

  // ── Estado inicial ─────────────────────────────────────────
  let darkMode = leerCookie('jis_dark_mode') === '1';
  let styleTag = null;

  function leerCookie(nombre) {
    const match = document.cookie.match(new RegExp('(^| )' + nombre + '=([^;]+)'));
    return match ? decodeURIComponent(match[2]) : '';
  }

  function guardarCookie(nombre, valor, dias) {
    const exp = new Date(Date.now() + dias * 864e5).toUTCString();
    document.cookie = `${nombre}=${encodeURIComponent(valor)};expires=${exp};path=/`;
  }

  function aplicarModo() {
    if (darkMode) {
      if (!styleTag) {
        styleTag = document.createElement('style');
        styleTag.id = 'jis-dark-mode';
        document.head.appendChild(styleTag);
      }
      styleTag.textContent = CSS_DARK;
      document.documentElement.setAttribute('data-theme', 'dark');
      btnIcon.textContent = '☀️';
      btnLabel.textContent = 'Modo claro';
    } else {
      if (styleTag) styleTag.textContent = '';
      document.documentElement.removeAttribute('data-theme');
      btnIcon.textContent = '🌙';
      btnLabel.textContent = 'Modo oscuro';
    }
  }

  // ── Botón flotante ─────────────────────────────────────────
  const btn = document.createElement('div');
  btn.id = 'dark-mode-btn';
  btn.style.cssText = `
    position: fixed;
    bottom: 100px;           /* encima del botón de chat */
    right: 25px;
    z-index: 1060;
    background: #1e293b;
    color: white;
    border: 2px solid #334155;
    border-radius: 50px;
    padding: 10px 16px;
    display: flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
    font-size: 13px;
    font-family: 'Inter', sans-serif;
    font-weight: 600;
    box-shadow: 0 4px 16px rgba(0,0,0,0.25);
    transition: all 0.25s ease;
    user-select: none;
  `;

  const btnIcon  = document.createElement('span');
  const btnLabel = document.createElement('span');
  btn.appendChild(btnIcon);
  btn.appendChild(btnLabel);

  btn.addEventListener('mouseenter', () => {
    btn.style.transform = 'scale(1.05)';
    btn.style.boxShadow = '0 6px 24px rgba(0,0,0,0.35)';
  });
  btn.addEventListener('mouseleave', () => {
    btn.style.transform = 'scale(1)';
    btn.style.boxShadow = '0 4px 16px rgba(0,0,0,0.25)';
  });

  btn.addEventListener('click', () => {
    darkMode = !darkMode;
    guardarCookie('jis_dark_mode', darkMode ? '1' : '0', 365);
    aplicarModo();
  });

  // ── Inicializar cuando el DOM esté listo ───────────────────
  function init() {
    document.body.appendChild(btn);
    aplicarModo();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
