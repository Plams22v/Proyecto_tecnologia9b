<?php
/**
 * ============================================================
 *  calendario_profes.php  –  Calendario Mensual de Asistencia
 *  Ubicación: JIS/Paginas/calendario_profes.php
 * ============================================================
 */
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../Login.php");
    exit();
}
include("../conexion.php");

// ── Parámetros de navegación ─────────────────────────────────
$hoy  = new DateTime();
$mes  = isset($_GET['mes'])  ? (int)$_GET['mes']  : (int)$hoy->format('n');
$anio = isset($_GET['anio']) ? (int)$_GET['anio'] : (int)$hoy->format('Y');

// Clamping
if ($mes < 1) { $mes = 12; $anio--; }
if ($mes > 12) { $mes = 1;  $anio++; }

// ── Cargar asistencia del mes en un mapa fecha→[registros] ───
$sql = "SELECT
            ap.id_asistencia,
            ap.fecha,
            ap.hora_llegada,
            ap.hora_salida,
            CONCAT(p.prim_nombre,' ',p.prim_apellido) AS nombre_prof,
            p.especialidad
        FROM asistencia_profesor ap
        JOIN profesor p ON p.id_prof = ap.id_prof
        WHERE MONTH(ap.fecha) = $mes
          AND YEAR(ap.fecha)  = $anio
        ORDER BY ap.hora_llegada ASC";

$res = $conexion->query($sql);
$asistencia_map = [];
while ($row = $res->fetch_assoc()) {
    $asistencia_map[$row['fecha']][] = $row;
}

// ── Profesores para el filtro ─────────────────────────────────
$profes_res = $conexion->query("SELECT id_prof, CONCAT(prim_nombre,' ',prim_apellido) AS nombre FROM profesor ORDER BY prim_apellido");
$profes = [];
while ($p = $profes_res->fetch_assoc()) $profes[] = $p;

// ── Estadísticas del mes ──────────────────────────────────────
$sql_stats = "SELECT
    COUNT(DISTINCT fecha)   AS dias_con_registro,
    COUNT(*)                AS total_registros,
    COUNT(DISTINCT id_prof) AS profes_activos
  FROM asistencia_profesor
  WHERE MONTH(fecha) = $mes AND YEAR(fecha) = $anio";
$stats = $conexion->query($sql_stats)->fetch_assoc();

// ── Helpers de calendario ─────────────────────────────────────
$primer_dia   = new DateTime("$anio-$mes-01");
$dias_en_mes  = (int)$primer_dia->format('t');
$dia_semana_inicio = (int)$primer_dia->format('N'); // 1=lun … 7=dom

$meses_es = ['','Enero','Febrero','Marzo','Abril','Mayo','Junio',
             'Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];

// Mes anterior / siguiente
$prev_mes  = $mes - 1 < 1  ? 12 : $mes - 1;
$prev_anio = $mes - 1 < 1  ? $anio - 1 : $anio;
$next_mes  = $mes + 1 > 12 ? 1  : $mes + 1;
$next_anio = $mes + 1 > 12 ? $anio + 1 : $anio;
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Calendario Asistencia – COSFA</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root { --primary-dark:#1e462f; --accent-green:#2d7a4d; --bg-gray:#f8fafc; }
    body { font-family:'Inter',sans-serif; background:var(--bg-gray); }

    .page-header { background:linear-gradient(135deg,#145c32,#2d7a4d); color:white; padding:28px 0; }
    .page-header h1 { font-size:1.5rem; font-weight:700; margin:0; }

    /* Stats bar */
    .stat-chip {
      background:white; border-radius:12px; padding:14px 22px;
      box-shadow:0 2px 10px rgba(0,0,0,.07);
      text-align:center;
    }
    .stat-chip .num { font-size:1.8rem; font-weight:700; color:var(--accent-green); line-height:1; }
    .stat-chip .lbl { font-size:.75rem; color:#64748b; margin-top:4px; font-weight:500; }

    /* Navegación del calendario */
    .cal-nav { display:flex; align-items:center; gap:16px; margin-bottom:20px; }
    .cal-nav a {
      background:white; border:1px solid #e2e8f0; border-radius:10px;
      padding:8px 16px; color:#334155; font-weight:600; text-decoration:none;
      transition:.15s;
    }
    .cal-nav a:hover { background:var(--accent-green); color:white; border-color:var(--accent-green); }
    .cal-nav h2 { margin:0; font-size:1.2rem; font-weight:700; color:#1e293b; }

    /* Grilla del calendario */
    .cal-grid {
      display:grid;
      grid-template-columns:repeat(7, 1fr);
      gap:6px;
    }
    .cal-header-day {
      text-align:center; font-size:.75rem; font-weight:700;
      color:#94a3b8; padding:8px 0; text-transform:uppercase;
    }
    .cal-day {
      background:white; border-radius:10px; border:1px solid #e2e8f0;
      min-height:90px; padding:8px; cursor:default; transition:.15s;
      position:relative; overflow:hidden;
    }
    .cal-day:hover { border-color:var(--accent-green); box-shadow:0 4px 12px rgba(45,122,77,.15); }
    .cal-day.vacio { background:transparent; border:none; }
    .cal-day.hoy   { border-color:var(--accent-green) !important; background:#f0fdf4; }
    .cal-day.hoy .num-dia { color:var(--accent-green); font-weight:700; }
    .cal-day.finde .num-dia { color:#94a3b8; }

    .num-dia { font-size:.85rem; font-weight:600; color:#475569; margin-bottom:4px; }

    /* Pills de asistencia dentro del día */
    .pill-prof {
      font-size:.65rem; font-weight:600; border-radius:6px;
      padding:2px 6px; margin-bottom:2px; background:#dcfce7; color:#166534;
      white-space:nowrap; overflow:hidden; text-overflow:ellipsis;
      display:block; cursor:pointer;
    }
    .pill-prof:hover { background:var(--accent-green); color:white; }
    .pill-mas {
      font-size:.65rem; color:#94a3b8; padding:2px 4px; display:block;
    }

    /* Modal de detalle del día */
    .modal-registro { border-left:3px solid var(--accent-green); padding:10px 14px; margin-bottom:8px; background:#f8fafc; border-radius:6px; }
    .modal-registro .prof-name { font-weight:600; color:#1e293b; font-size:.9rem; }
    .modal-registro .horario { font-size:.8rem; color:#64748b; margin-top:2px; }
  </style>
</head>
<body>

<?php include("../handlers/sidebar.php"); ?>

<div class="d-flex" style="min-height:100vh;">
<div class="flex-grow-1">

  <div class="page-header">
    <div class="container">
      <h1><i class="bi bi-calendar3 me-2"></i>Calendario de Asistencia – Profesores</h1>
      <p class="mb-0 opacity-75 mt-1">Vista mensual de registros de llegada y salida</p>
    </div>
  </div>

  <div class="container py-4">

    <!-- Stats -->
    <div class="row g-3 mb-4">
      <div class="col-6 col-md-3">
        <div class="stat-chip">
          <div class="num"><?= $stats['dias_con_registro'] ?? 0 ?></div>
          <div class="lbl">Días con registros</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-chip">
          <div class="num"><?= $stats['total_registros'] ?? 0 ?></div>
          <div class="lbl">Registros totales</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-chip">
          <div class="num"><?= $stats['profes_activos'] ?? 0 ?></div>
          <div class="lbl">Profes activos</div>
        </div>
      </div>
      <div class="col-6 col-md-3">
        <div class="stat-chip">
          <div class="num"><?= count($profes) ?></div>
          <div class="lbl">Total profesores</div>
        </div>
      </div>
    </div>

    <!-- Navegación -->
    <div class="cal-nav">
      <a href="?mes=<?= $prev_mes ?>&anio=<?= $prev_anio ?>">
        <i class="bi bi-chevron-left"></i>
      </a>
      <h2><?= $meses_es[$mes] ?> <?= $anio ?></h2>
      <a href="?mes=<?= $next_mes ?>&anio=<?= $next_anio ?>">
        <i class="bi bi-chevron-right"></i>
      </a>
      <a href="?mes=<?= $hoy->format('n') ?>&anio=<?= $hoy->format('Y') ?>"
         class="ms-auto" style="font-size:.85rem;">
        Hoy
      </a>
    </div>

    <!-- Calendario -->
    <div class="cal-grid">
      <!-- Encabezados días -->
      <?php foreach (['Lun','Mar','Mié','Jue','Vie','Sáb','Dom'] as $d): ?>
        <div class="cal-header-day"><?= $d ?></div>
      <?php endforeach; ?>

      <!-- Celdas vacías antes del primer día -->
      <?php for ($v = 1; $v < $dia_semana_inicio; $v++): ?>
        <div class="cal-day vacio"></div>
      <?php endfor; ?>

      <!-- Días del mes -->
      <?php
      $hoy_str = $hoy->format('Y-m-d');
      for ($dia = 1; $dia <= $dias_en_mes; $dia++):
          $fecha_str = sprintf('%04d-%02d-%02d', $anio, $mes, $dia);
          $dow = (int)(new DateTime($fecha_str))->format('N'); // 1=lun
          $es_hoy   = ($fecha_str === $hoy_str);
          $es_finde = ($dow >= 6);
          $registros = $asistencia_map[$fecha_str] ?? [];
          $tiene     = !empty($registros);
          $clases    = 'cal-day' . ($es_hoy ? ' hoy' : '') . ($es_finde ? ' finde' : '');
      ?>
      <div class="<?= $clases ?>"
           <?= $tiene ? "onclick=\"abrirModal('$fecha_str', $dia)\" style='cursor:pointer;'" : '' ?>>
        <div class="num-dia"><?= $dia ?></div>
        <?php
        $max_pills = 3;
        $i = 0;
        foreach ($registros as $reg):
            if ($i >= $max_pills) break;
            $nombre_corto = explode(' ', $reg['nombre_prof'])[0];
        ?>
          <span class="pill-prof"
                title="<?= htmlspecialchars($reg['nombre_prof']) ?> – <?= $reg['hora_llegada'] ?>">
            <?= htmlspecialchars($nombre_corto) ?>
          </span>
        <?php $i++; endforeach; ?>
        <?php if (count($registros) > $max_pills): ?>
          <span class="pill-mas">+<?= count($registros) - $max_pills ?> más</span>
        <?php endif; ?>
      </div>
      <?php endfor; ?>
    </div><!-- /cal-grid -->

    <!-- Leyenda -->
    <div class="d-flex gap-3 mt-3 flex-wrap">
      <div class="d-flex align-items-center gap-2">
        <div style="width:14px;height:14px;background:#dcfce7;border-radius:4px;"></div>
        <span class="text-muted small">Con registros</span>
      </div>
      <div class="d-flex align-items-center gap-2">
        <div style="width:14px;height:14px;background:#f0fdf4;border:2px solid var(--accent-green);border-radius:4px;"></div>
        <span class="text-muted small">Hoy</span>
      </div>
    </div>

  </div><!-- /container -->
</div><!-- /flex-grow -->
</div>

<!-- Modal detalle del día -->
<div class="modal fade" id="modalDia" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow">
      <div class="modal-header"
           style="background:linear-gradient(135deg,#145c32,#2d7a4d); color:white; border:none;">
        <h5 class="modal-title fw-bold">
          <i class="bi bi-calendar-check me-2"></i>
          <span id="modal-titulo">Detalle del día</span>
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="modal-body" style="max-height:420px; overflow-y:auto;">
        <!-- Contenido inyectado por JS -->
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Datos del servidor para el modal
const asistenciaData = <?= json_encode($asistencia_map, JSON_UNESCAPED_UNICODE) ?>;
const mesesEs = ['','Enero','Febrero','Marzo','Abril','Mayo','Junio',
                 'Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];

function abrirModal(fechaStr, dia) {
  const registros = asistenciaData[fechaStr] || [];
  const [anio, mes] = fechaStr.split('-');

  document.getElementById('modal-titulo').textContent =
    dia + ' de ' + mesesEs[parseInt(mes)] + ' ' + anio;

  let html = '';
  if (registros.length === 0) {
    html = '<p class="text-muted text-center py-3">Sin registros este día.</p>';
  } else {
    registros.forEach(r => {
      const salida = r.hora_salida ? r.hora_salida : '<em class="text-muted">No registrada</em>';
      html += `
        <div class="modal-registro">
          <div class="prof-name">
            <i class="bi bi-person-badge-fill text-success me-1"></i>
            ${r.nombre_prof}
          </div>
          <div class="horario">
            ${r.especialidad ? '📚 ' + r.especialidad + ' &nbsp;|&nbsp;' : ''}
            🕐 Llegada: <strong>${r.hora_llegada}</strong> &nbsp;·&nbsp;
            🕓 Salida: <strong>${salida}</strong>
          </div>
        </div>`;
    });
  }

  document.getElementById('modal-body').innerHTML = html;
  new bootstrap.Modal(document.getElementById('modalDia')).show();
}
</script>
</body>
</html>
