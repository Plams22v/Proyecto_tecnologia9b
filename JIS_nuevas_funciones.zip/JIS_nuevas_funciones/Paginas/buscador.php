<?php
/**
 * ============================================================
 *  buscador.php  –  Buscador Global del Sistema JIS
 *  Ubicación: JIS/Paginas/buscador.php
 * ============================================================
 */
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../Login.php");
    exit();
}
include("../conexion.php");

$query    = trim($_GET['q'] ?? '');
$filtro   = $_GET['filtro'] ?? 'todo';   // todo | estudiantes | profesores | acudientes | salidas
$resultados = [];
$total      = 0;

if ($query !== '') {
    $q = $conexion->real_escape_string($query);

    // ── Estudiantes ───────────────────────────────────────────
    if ($filtro === 'todo' || $filtro === 'estudiantes') {
        $sql = "SELECT 'estudiante' AS tipo,
                       id_est       AS id,
                       CONCAT(prim_nombre,' ',COALESCE(seg_nombre,''),' ',
                              prim_apellido,' ',COALESCE(seg_apellido,'')) AS nombre,
                       grado        AS detalle,
                       documento    AS extra,
                       NULL         AS fecha
                FROM estudiante
                WHERE prim_nombre   LIKE '%$q%'
                   OR prim_apellido LIKE '%$q%'
                   OR seg_nombre    LIKE '%$q%'
                   OR seg_apellido  LIKE '%$q%'
                   OR documento     LIKE '%$q%'
                   OR grado         LIKE '%$q%'
                LIMIT 20";
        $r = $conexion->query($sql);
        while ($row = $r->fetch_assoc()) $resultados[] = $row;
    }

    // ── Profesores ────────────────────────────────────────────
    if ($filtro === 'todo' || $filtro === 'profesores') {
        $sql = "SELECT 'profesor' AS tipo,
                       id_prof     AS id,
                       CONCAT(prim_nombre,' ',COALESCE(seg_nombre,''),' ',
                              prim_apellido,' ',COALESCE(seg_apellido,'')) AS nombre,
                       especialidad AS detalle,
                       documento    AS extra,
                       NULL         AS fecha
                FROM profesor
                WHERE prim_nombre   LIKE '%$q%'
                   OR prim_apellido LIKE '%$q%'
                   OR documento     LIKE '%$q%'
                   OR especialidad  LIKE '%$q%'
                LIMIT 20";
        $r = $conexion->query($sql);
        while ($row = $r->fetch_assoc()) $resultados[] = $row;
    }

    // ── Acudientes ────────────────────────────────────────────
    if ($filtro === 'todo' || $filtro === 'acudientes') {
        $sql = "SELECT 'acudiente' AS tipo,
                       id_acudiente AS id,
                       CONCAT(prim_nombre,' ',COALESCE(seg_nombre,''),' ',
                              prim_apellido,' ',COALESCE(seg_apellido,'')) AS nombre,
                       telefono     AS detalle,
                       documento    AS extra,
                       NULL         AS fecha
                FROM acudiente
                WHERE prim_nombre   LIKE '%$q%'
                   OR prim_apellido LIKE '%$q%'
                   OR documento     LIKE '%$q%'
                   OR telefono      LIKE '%$q%'
                LIMIT 20";
        $r = $conexion->query($sql);
        while ($row = $r->fetch_assoc()) $resultados[] = $row;
    }

    // ── Salidas de estudiantes ────────────────────────────────
    if ($filtro === 'todo' || $filtro === 'salidas') {
        $sql = "SELECT 'salida' AS tipo,
                       s.id_salida  AS id,
                       CONCAT(e.prim_nombre,' ',e.prim_apellido) AS nombre,
                       s.motivo     AS detalle,
                       e.grado      AS extra,
                       DATE_FORMAT(s.fecha_salida,'%d/%m/%Y %H:%i') AS fecha
                FROM salida_est s
                JOIN estudiante e ON e.id_est = s.id_est
                WHERE s.motivo          LIKE '%$q%'
                   OR e.prim_nombre     LIKE '%$q%'
                   OR e.prim_apellido   LIKE '%$q%'
                   OR e.grado           LIKE '%$q%'
                ORDER BY s.fecha_salida DESC
                LIMIT 20";
        $r = $conexion->query($sql);
        while ($row = $r->fetch_assoc()) $resultados[] = $row;
    }

    $total = count($resultados);
}

// ── Helpers de UI ─────────────────────────────────────────────
$iconos = [
    'estudiante' => 'bi-mortarboard-fill',
    'profesor'   => 'bi-person-badge-fill',
    'acudiente'  => 'bi-people-fill',
    'salida'     => 'bi-door-open-fill',
];
$colores = [
    'estudiante' => '#2d7a4d',
    'profesor'   => '#1d4ed8',
    'acudiente'  => '#7c3aed',
    'salida'     => '#b45309',
];
$etiquetas = [
    'estudiante' => 'Estudiante',
    'profesor'   => 'Profesor',
    'acudiente'  => 'Acudiente',
    'salida'     => 'Salida',
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Buscador Global – COSFA</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --primary-dark: #1e462f;
      --accent-green: #2d7a4d;
      --bg-gray: #f8fafc;
    }
    body { font-family: 'Inter', sans-serif; background: var(--bg-gray); }

    /* Barra de búsqueda */
    .search-hero {
      background: linear-gradient(135deg, #145c32, #2d7a4d);
      padding: 48px 0 36px;
      color: white;
    }
    .search-hero h1 { font-size: 1.8rem; font-weight: 700; margin-bottom: 6px; }
    .search-hero p  { opacity: .8; font-size: .95rem; margin-bottom: 24px; }

    .search-bar {
      display: flex;
      background: white;
      border-radius: 14px;
      box-shadow: 0 8px 32px rgba(0,0,0,.18);
      overflow: hidden;
    }
    .search-bar input {
      flex: 1;
      border: none;
      padding: 16px 20px;
      font-size: 16px;
      outline: none;
    }
    .search-bar button {
      background: var(--accent-green);
      color: white;
      border: none;
      padding: 0 28px;
      font-size: 20px;
      cursor: pointer;
      transition: background .2s;
    }
    .search-bar button:hover { background: var(--primary-dark); }

    /* Filtros */
    .filtros .btn-check:checked + .btn-outline-secondary {
      background: var(--accent-green);
      color: white;
      border-color: var(--accent-green);
    }

    /* Tarjeta resultado */
    .result-card {
      background: white;
      border-radius: 12px;
      border: 1px solid #e2e8f0;
      padding: 18px 22px;
      display: flex;
      align-items: flex-start;
      gap: 16px;
      transition: box-shadow .2s, transform .15s;
      cursor: default;
    }
    .result-card:hover {
      box-shadow: 0 6px 20px rgba(0,0,0,.10);
      transform: translateY(-2px);
    }
    .result-icon {
      width: 46px; height: 46px;
      border-radius: 10px;
      display: flex; align-items: center; justify-content: center;
      font-size: 20px; color: white;
      flex-shrink: 0;
    }
    .result-nombre { font-weight: 600; color: #1e293b; font-size: 1rem; }
    .result-detalle { color: #64748b; font-size: .875rem; margin-top: 3px; }
    .result-badge {
      font-size: .72rem; font-weight: 600; padding: 3px 10px;
      border-radius: 99px; color: white;
    }
    .no-results {
      text-align: center; padding: 60px 20px; color: #94a3b8;
    }
    .no-results i { font-size: 56px; display: block; margin-bottom: 16px; }
    .highlight { background: #fef08a; border-radius: 3px; padding: 0 2px; }
  </style>
</head>
<body>

<?php include("../handlers/sidebar.php"); ?>

<div class="d-flex" style="min-height:100vh;">
  <!-- Contenido principal -->
  <div class="flex-grow-1">

    <!-- Hero de búsqueda -->
    <div class="search-hero">
      <div class="container" style="max-width:720px;">
        <h1><i class="bi bi-search me-2"></i>Buscador Global</h1>
        <p>Busca estudiantes, profesores, acudientes o registros de salidas</p>

        <form method="GET" action="buscador.php">
          <div class="search-bar">
            <input type="text"
                   name="q"
                   value="<?= htmlspecialchars($query) ?>"
                   placeholder="Escribe un nombre, documento, grado, motivo..."
                   autofocus>
            <button type="submit"><i class="bi bi-search"></i></button>
          </div>

          <!-- Filtros -->
          <div class="filtros d-flex flex-wrap gap-2 mt-3">
            <?php
            $filtros_opts = [
                'todo'        => 'Todo',
                'estudiantes' => 'Estudiantes',
                'profesores'  => 'Profesores',
                'acudientes'  => 'Acudientes',
                'salidas'     => 'Salidas',
            ];
            foreach ($filtros_opts as $val => $label):
                $checked = ($filtro === $val) ? 'checked' : '';
            ?>
            <input type="radio" class="btn-check" name="filtro" id="f_<?= $val ?>"
                   value="<?= $val ?>" <?= $checked ?>>
            <label class="btn btn-sm btn-outline-secondary text-white border-white border-opacity-50
                          rounded-pill px-3" for="f_<?= $val ?>">
              <?= $label ?>
            </label>
            <?php endforeach; ?>
          </div>
        </form>
      </div>
    </div>

    <!-- Resultados -->
    <div class="container py-4" style="max-width:720px;">

      <?php if ($query !== ''): ?>
        <div class="d-flex justify-content-between align-items-center mb-3">
          <span class="text-muted small">
            <?= $total > 0
              ? "<strong>{$total}</strong> resultado(s) para <em>\"" . htmlspecialchars($query) . "\"</em>"
              : "Sin resultados para <em>\"" . htmlspecialchars($query) . "\"</em>"
            ?>
          </span>
        </div>
      <?php endif; ?>

      <?php if ($query !== '' && $total === 0): ?>
        <div class="no-results">
          <i class="bi bi-inbox"></i>
          <h5>No encontramos nada</h5>
          <p class="text-muted">Prueba con otro término o cambia el filtro</p>
        </div>

      <?php elseif ($total > 0): ?>
        <div class="d-flex flex-column gap-3">
          <?php foreach ($resultados as $r):
            $tipo   = $r['tipo'];
            $icono  = $iconos[$tipo]  ?? 'bi-question';
            $color  = $colores[$tipo] ?? '#64748b';
            $badge  = $etiquetas[$tipo] ?? $tipo;

            // Resaltar término buscado en nombre y detalle
            $nombre  = htmlspecialchars(trim($r['nombre']));
            $detalle = htmlspecialchars($r['detalle'] ?? '');
            $extra   = htmlspecialchars($r['extra'] ?? '');
            $fecha   = $r['fecha'] ?? '';

            if ($query) {
                $esc = preg_quote(htmlspecialchars($query), '/');
                $nombre  = preg_replace("/({$esc})/i", '<mark class="highlight">$1</mark>', $nombre);
                $detalle = preg_replace("/({$esc})/i", '<mark class="highlight">$1</mark>', $detalle);
            }
          ?>
          <div class="result-card">
            <div class="result-icon" style="background:<?= $color ?>">
              <i class="bi <?= $icono ?>"></i>
            </div>
            <div class="flex-grow-1">
              <div class="d-flex align-items-center gap-2 flex-wrap">
                <span class="result-nombre"><?= $nombre ?></span>
                <span class="result-badge" style="background:<?= $color ?>">
                  <?= $badge ?>
                </span>
              </div>
              <div class="result-detalle"><?= $detalle ?></div>
              <?php if ($extra): ?>
                <div class="result-detalle">
                  <i class="bi bi-credit-card me-1"></i><?= $extra ?>
                </div>
              <?php endif; ?>
              <?php if ($fecha): ?>
                <div class="result-detalle mt-1">
                  <i class="bi bi-clock me-1"></i><?= $fecha ?>
                </div>
              <?php endif; ?>
            </div>
          </div>
          <?php endforeach; ?>
        </div>

      <?php elseif ($query === ''): ?>
        <!-- Estado inicial -->
        <div class="no-results">
          <i class="bi bi-search" style="color:#cbd5e1;"></i>
          <h5 class="text-muted">Empieza a buscar</h5>
          <p class="text-muted">
            Puedes buscar por nombre, apellido, documento, grado o motivo de salida
          </p>
        </div>
      <?php endif; ?>
    </div><!-- /container -->
  </div><!-- /flex-grow-1 -->
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- Auto-submit al cambiar filtro radio -->
<script>
  document.querySelectorAll('input[name="filtro"]').forEach(r => {
    r.addEventListener('change', () => r.closest('form').submit());
  });
</script>
</body>
</html>
