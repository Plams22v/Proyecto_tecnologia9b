<?php
/**
 * ============================================================
 *  reportes.php  –  Módulo de Reportes Exportables JIS
 *  Ubicación: JIS/Paginas/reportes.php
 *
 *  DEPENDENCIAS (instalar con Composer):
 *    composer require phpoffice/phpspreadsheet
 *    (fpdf ya está incluido en JIS/pdf/fpdf.php)
 * ============================================================
 */
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../Login.php");
    exit();
}
include("../conexion.php");

$hoy        = date('Y-m-d');
$fecha_ini  = $_GET['fecha_ini']  ?? date('Y-m-01');  // primer día del mes
$fecha_fin  = $_GET['fecha_fin']  ?? $hoy;
$tipo_rep   = $_GET['tipo']       ?? 'salidas_est';
$exportar   = $_GET['exportar']   ?? '';

// ── Sanitizar fechas ──────────────────────────────────────────
$fecha_ini = preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha_ini) ? $fecha_ini : date('Y-m-01');
$fecha_fin = preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha_fin) ? $fecha_fin : $hoy;

// ── Consultas por tipo de reporte ─────────────────────────────
function obtenerDatos($conexion, string $tipo, string $fi, string $ff): array {
    $fi = $conexion->real_escape_string($fi);
    $ff = $conexion->real_escape_string($ff);

    $queries = [
        'salidas_est' =>
            "SELECT
                s.id_salida             AS 'ID',
                CONCAT(e.prim_nombre,' ',e.prim_apellido) AS 'Estudiante',
                e.grado                 AS 'Grado',
                CONCAT(a.prim_nombre,' ',a.prim_apellido) AS 'Acudiente',
                a.telefono              AS 'Teléfono acudiente',
                s.motivo                AS 'Motivo',
                DATE_FORMAT(s.fecha_salida,'%d/%m/%Y') AS 'Fecha',
                DATE_FORMAT(s.fecha_salida,'%H:%i')    AS 'Hora',
                s.usuario_registro      AS 'Registrado por'
             FROM salida_est s
             JOIN estudiante e ON e.id_est = s.id_est
             LEFT JOIN acudiente a ON a.id_acudiente = s.id_acudiente
             WHERE DATE(s.fecha_salida) BETWEEN '$fi' AND '$ff'
             ORDER BY s.fecha_salida DESC",

        'parqueadero' =>
            "SELECT
                id_parq                 AS 'ID',
                placa                   AS 'Placa',
                nom_propietario         AS 'Propietario',
                tipo_vehiculo           AS 'Tipo vehículo',
                hora_entrada            AS 'Entrada',
                hora_salida             AS 'Salida',
                DATE_FORMAT(creado_en,'%d/%m/%Y') AS 'Fecha'
             FROM salida_parq
             WHERE DATE(creado_en) BETWEEN '$fi' AND '$ff'
             ORDER BY creado_en DESC",

        'asistencia_prof' =>
            "SELECT
                ap.id_asistencia        AS 'ID',
                CONCAT(p.prim_nombre,' ',p.prim_apellido) AS 'Profesor',
                p.especialidad          AS 'Especialidad',
                DATE_FORMAT(ap.fecha,'%d/%m/%Y') AS 'Fecha',
                ap.hora_llegada         AS 'Llegada',
                COALESCE(ap.hora_salida,'—') AS 'Salida'
             FROM asistencia_profesor ap
             JOIN profesor p ON p.id_prof = ap.id_prof
             WHERE ap.fecha BETWEEN '$fi' AND '$ff'
             ORDER BY ap.fecha DESC, ap.hora_llegada ASC",
    ];

    $sql = $queries[$tipo] ?? $queries['salidas_est'];
    $res = $conexion->query($sql);
    if (!$res) return [];

    $rows = [];
    while ($row = $res->fetch_assoc()) $rows[] = $row;
    return $rows;
}

$datos = obtenerDatos($conexion, $tipo_rep, $fecha_ini, $fecha_fin);

// ── Exportar Excel ────────────────────────────────────────────
if ($exportar === 'excel' && !empty($datos)) {
    require_once __DIR__ . '/../vendor/autoload.php';

    $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Encabezados
    $cols = array_keys($datos[0]);
    foreach ($cols as $i => $col) {
        $letra = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($i + 1);
        $cell  = $letra . '1';
        $sheet->setCellValue($cell, $col);
        $sheet->getStyle($cell)->getFont()->setBold(true);
        $sheet->getStyle($cell)->getFill()
              ->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
              ->getStartColor()->setRGB('145c32');
        $sheet->getStyle($cell)->getFont()->getColor()->setRGB('FFFFFF');
    }

    // Datos
    foreach ($datos as $fila => $row) {
        foreach (array_values($row) as $ci => $val) {
            $letra = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($ci + 1);
            $sheet->setCellValue($letra . ($fila + 2), $val);
        }
    }

    // Auto-ancho columnas
    foreach (range(1, count($cols)) as $ci) {
        $letra = \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex($ci);
        $sheet->getColumnDimension($letra)->setAutoSize(true);
    }

    $nombre_archivo = 'Reporte_JIS_' . $tipo_rep . '_' . $fecha_ini . '_' . $fecha_fin . '.xlsx';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header("Content-Disposition: attachment; filename=\"{$nombre_archivo}\"");
    header('Cache-Control: max-age=0');

    $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
    $writer->save('php://output');
    exit;
}

// ── Exportar PDF ──────────────────────────────────────────────
if ($exportar === 'pdf' && !empty($datos)) {
    require_once __DIR__ . '/../pdf/fpdf.php';

    $pdf = new FPDF('L', 'mm', 'A4');
    $pdf->AddPage();
    $pdf->SetFont('Helvetica', 'B', 14);
    $pdf->SetFillColor(20, 92, 50);
    $pdf->SetTextColor(255, 255, 255);
    $pdf->Cell(0, 10, 'Reporte JIS - ' . strtoupper($tipo_rep) . '  | ' . $fecha_ini . ' al ' . $fecha_fin, 0, 1, 'C', true);
    $pdf->Ln(4);

    // Encabezados tabla
    $cols = array_keys($datos[0]);
    $ancho_col = (int)(267 / count($cols));

    $pdf->SetFont('Helvetica', 'B', 8);
    $pdf->SetFillColor(45, 122, 77);
    $pdf->SetTextColor(255, 255, 255);
    foreach ($cols as $col) {
        $pdf->Cell($ancho_col, 8, mb_convert_encoding($col, 'ISO-8859-1', 'UTF-8'), 1, 0, 'C', true);
    }
    $pdf->Ln();

    // Filas
    $pdf->SetFont('Helvetica', '', 7);
    $pdf->SetTextColor(30, 41, 59);
    $fill = false;
    foreach ($datos as $row) {
        $pdf->SetFillColor($fill ? 240 : 255, $fill ? 253 : 255, $fill ? 244 : 255);
        foreach (array_values($row) as $val) {
            $val = mb_convert_encoding((string)$val, 'ISO-8859-1', 'UTF-8');
            $pdf->Cell($ancho_col, 7, $val, 1, 0, 'L', $fill);
        }
        $pdf->Ln();
        $fill = !$fill;
    }

    $pdf->Output('D', 'Reporte_JIS_' . $tipo_rep . '.pdf');
    exit;
}

// ── Tipos de reporte disponibles ──────────────────────────────
$tipos = [
    'salidas_est'     => ['label' => 'Salidas de Estudiantes', 'icono' => 'bi-door-open-fill'],
    'parqueadero'     => ['label' => 'Parqueadero',            'icono' => 'bi-car-front-fill'],
    'asistencia_prof' => ['label' => 'Asistencia Profesores',  'icono' => 'bi-person-badge-fill'],
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reportes – COSFA</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root { --primary-dark:#1e462f; --accent-green:#2d7a4d; --bg-gray:#f8fafc; }
    body { font-family:'Inter',sans-serif; background:var(--bg-gray); }
    .page-header { background:linear-gradient(135deg,#145c32,#2d7a4d); color:white; padding:32px 0; }
    .page-header h1 { font-size:1.6rem; font-weight:700; margin:0; }

    /* Selector de tipo */
    .tipo-card {
      border:2px solid #e2e8f0; border-radius:12px; padding:16px 20px;
      cursor:pointer; transition:.2s; background:white; text-align:center;
    }
    .tipo-card:hover, .tipo-card.activo {
      border-color:var(--accent-green); background:#f0fdf4;
    }
    .tipo-card i { font-size:26px; color:var(--accent-green); display:block; margin-bottom:6px; }
    .tipo-card span { font-weight:600; font-size:.875rem; color:#334155; }

    /* Tabla */
    .tabla-reporte { border-radius:12px; overflow:hidden; }
    .tabla-reporte thead th {
      background:var(--accent-green); color:white;
      font-weight:600; font-size:.8rem; border:none; padding:12px 14px;
    }
    .tabla-reporte tbody tr:hover { background:#f0fdf4; }
    .tabla-reporte tbody td { font-size:.85rem; padding:10px 14px; border-color:#f1f5f9; }
    .btn-export {
      display:inline-flex; align-items:center; gap:8px;
      padding:10px 20px; border-radius:10px; font-weight:600; border:none; cursor:pointer;
      transition:.2s;
    }
    .btn-excel { background:#217346; color:white; }
    .btn-excel:hover { background:#1a5c38; color:white; }
    .btn-pdf   { background:#c0392b; color:white; }
    .btn-pdf:hover   { background:#a93226; color:white; }
  </style>
</head>
<body>

<?php include("../handlers/sidebar.php"); ?>

<div class="d-flex" style="min-height:100vh;">
<div class="flex-grow-1">

  <div class="page-header">
    <div class="container">
      <h1><i class="bi bi-file-earmark-bar-graph me-2"></i>Módulo de Reportes</h1>
      <p class="mb-0 mt-1 opacity-75">Genera y exporta reportes por rango de fechas</p>
    </div>
  </div>

  <div class="container py-4">

    <!-- Selector de tipo de reporte -->
    <div class="row g-3 mb-4">
      <?php foreach ($tipos as $key => $info): ?>
      <div class="col-6 col-md-4">
        <div class="tipo-card <?= $tipo_rep === $key ? 'activo' : '' ?>"
             onclick="cambiarTipo('<?= $key ?>')">
          <i class="bi <?= $info['icono'] ?>"></i>
          <span><?= $info['label'] ?></span>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Formulario de filtros -->
    <form method="GET" action="reportes.php" id="form-reporte">
      <input type="hidden" name="tipo" id="input-tipo" value="<?= htmlspecialchars($tipo_rep) ?>">

      <div class="card border-0 shadow-sm rounded-3 mb-4">
        <div class="card-body">
          <div class="row g-3 align-items-end">
            <div class="col-md-4">
              <label class="form-label fw-semibold small text-muted text-uppercase">Desde</label>
              <input type="date" name="fecha_ini" class="form-control"
                     value="<?= $fecha_ini ?>" max="<?= $hoy ?>">
            </div>
            <div class="col-md-4">
              <label class="form-label fw-semibold small text-muted text-uppercase">Hasta</label>
              <input type="date" name="fecha_fin" class="form-control"
                     value="<?= $fecha_fin ?>" max="<?= $hoy ?>">
            </div>
            <div class="col-md-4">
              <button type="submit" class="btn btn-success w-100 fw-bold">
                <i class="bi bi-funnel me-1"></i>Filtrar
              </button>
            </div>
          </div>
        </div>
      </div>
    </form>

    <!-- Resultados -->
    <?php if (!empty($datos)): ?>

      <!-- Controles de exportación -->
      <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <span class="text-muted small fw-semibold">
          <i class="bi bi-table me-1"></i>
          <?= count($datos) ?> registro(s) · <?= $fecha_ini ?> al <?= $fecha_fin ?>
        </span>
        <div class="d-flex gap-2">
          <a href="reportes.php?tipo=<?= $tipo_rep ?>&fecha_ini=<?= $fecha_ini ?>&fecha_fin=<?= $fecha_fin ?>&exportar=excel"
             class="btn-export btn-excel">
            <i class="bi bi-file-earmark-excel-fill"></i> Excel
          </a>
          <a href="reportes.php?tipo=<?= $tipo_rep ?>&fecha_ini=<?= $fecha_ini ?>&fecha_fin=<?= $fecha_fin ?>&exportar=pdf"
             class="btn-export btn-pdf">
            <i class="bi bi-file-earmark-pdf-fill"></i> PDF
          </a>
        </div>
      </div>

      <!-- Tabla responsive -->
      <div class="table-responsive shadow-sm rounded-3">
        <table class="table table-bordered tabla-reporte mb-0">
          <thead>
            <tr>
              <?php foreach (array_keys($datos[0]) as $col): ?>
                <th><?= htmlspecialchars($col) ?></th>
              <?php endforeach; ?>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($datos as $fila): ?>
            <tr>
              <?php foreach ($fila as $val): ?>
                <td><?= htmlspecialchars((string)$val) ?></td>
              <?php endforeach; ?>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

    <?php elseif ($fecha_ini): ?>
      <div class="text-center py-5 text-muted">
        <i class="bi bi-inbox fs-1"></i>
        <p class="mt-3">No hay datos en ese rango de fechas.</p>
      </div>
    <?php endif; ?>

  </div><!-- /container -->
</div><!-- /flex-grow-1 -->
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function cambiarTipo(tipo) {
  document.getElementById('input-tipo').value = tipo;
  document.getElementById('form-reporte').submit();
}
</script>
</body>
</html>
