# 🆕 Nuevas Funciones – Sistema JIS (COSFA)
## Guía de integración completa

---

## 📁 Estructura de archivos entregados

```
JIS_nuevas_funciones/
├── handlers/
│   └── notificar_acudiente.php     ← 📧 Notificaciones por email
├── Paginas/
│   ├── buscador.php                ← 🔍 Buscador global
│   ├── reportes.php                ← 📊 Reportes Excel/PDF
│   └── calendario_profes.php       ← 📅 Calendario de asistencia
└── Assets/
    └── dark-mode.js                ← 🎁 Modo oscuro (sorpresa)
```

Copia cada archivo a su carpeta correspondiente dentro de tu proyecto `JIS/`.

---

## 1️⃣ 📧 Notificaciones por email al acudiente

**Archivo:** `handlers/notificar_acudiente.php`

### Paso 1 – Instalar PHPMailer con Composer
Abre una terminal en la raíz de tu proyecto `JIS/` y ejecuta:
```bash
composer require phpmailer/phpmailer
```

### Paso 2 – Configurar credenciales SMTP
Abre `notificar_acudiente.php` y edita la sección `SMTP CONFIG`:
```php
$smtp_host     = 'smtp.gmail.com';            // servidor SMTP
$smtp_usuario  = 'correo_colegio@gmail.com';  // tu correo
$smtp_password = 'tu_contrasena_app';         // contraseña de aplicación Gmail
$smtp_puerto   = 587;
```
> Con Gmail: ve a tu cuenta → Seguridad → **Contraseñas de aplicación** → genera una.

### Paso 3 – Llamar la función desde `guardar_salida_est.php`
Al final de `handlers/guardar_salida_est.php`, **antes del último `header(...)`**, añade:

```php
// ── NOTIFICACIÓN EMAIL ─────────────────────────────────
require_once __DIR__ . '/notificar_acudiente.php';

// Obtener datos del estudiante y acudiente
$sql_notif = "SELECT e.*, a.*
              FROM estudiante e
              LEFT JOIN acudiente a ON a.id_acudiente = e.id_acudiente
              WHERE e.id_est = $id_est LIMIT 1";
$res_notif  = $conexion->query($sql_notif);
if ($res_notif && $res_notif->num_rows > 0) {
    $datos_notif = $res_notif->fetch_assoc();
    $est  = ['prim_nombre'  => $datos_notif['prim_nombre'],
             'prim_apellido'=> $datos_notif['prim_apellido'],
             'grado'        => $datos_notif['grado']];
    $acud = ['prim_nombre'  => $datos_notif['prim_nombre'],   // del acudiente (mismo alias)
             'prim_apellido'=> $datos_notif['prim_apellido'],
             'email_acudiente' => $datos_notif['email_acudiente']];
    enviarNotificacionSalida($est, $acud, $motivo, date('d/m/Y H:i'));
}
```
> El correo se envía de forma silenciosa; si falla, NO interrumpe el flujo de la aplicación.

---

## 2️⃣ 🔍 Buscador Global

**Archivo:** `Paginas/buscador.php`  
No requiere ninguna dependencia adicional.

### Integración en sidebar (`handlers/sidebar.php`)
Añade este enlace en la sección `<nav>` del sidebar, junto a los demás módulos:

```php
<a href="buscador.php"
   class="nav-link text-white mb-2 <?php echo ($pagina_actual=='buscador.php')?'active bg-success shadow':''; ?>">
  <i class="bi bi-search me-2"></i> Buscador
</a>
```

### Integración en el panel principal (`Paginas/index2.php`)
Añade una tarjeta en el `<div class="row g-4">`:

```html
<div class="col-6 col-md-4 col-xl-3">
    <a href="buscador.php" class="card-nav shadow-sm">
        <div class="icon-wrapper"><i class="bi bi-search"></i></div>
        <span class="card-title-nav">Buscador</span>
        <span class="card-desc d-none d-sm-block">Búsqueda global</span>
    </a>
</div>
```

---

## 3️⃣ 📊 Reportes Exportables (Excel + PDF)

**Archivo:** `Paginas/reportes.php`

### Paso 1 – Instalar PhpSpreadsheet
```bash
composer require phpoffice/phpspreadsheet
```
> `fpdf.php` ya está en tu proyecto en `JIS/pdf/fpdf.php` ✅

### Integración en sidebar
```php
<a href="reportes.php"
   class="nav-link text-white mb-2 <?php echo ($pagina_actual=='reportes.php')?'active bg-success shadow':''; ?>">
  <i class="bi bi-file-earmark-bar-graph me-2"></i> Reportes
</a>
```

### Integración en el panel principal
```html
<div class="col-6 col-md-4 col-xl-3">
    <a href="reportes.php" class="card-nav shadow-sm">
        <div class="icon-wrapper"><i class="bi bi-file-earmark-bar-graph"></i></div>
        <span class="card-title-nav">Reportes</span>
        <span class="card-desc d-none d-sm-block">Excel y PDF</span>
    </a>
</div>
```

---

## 4️⃣ 📅 Calendario de Asistencia de Profesores

**Archivo:** `Paginas/calendario_profes.php`  
No requiere dependencias adicionales.

### Integración en sidebar
```php
<a href="calendario_profes.php"
   class="nav-link text-white mb-2 <?php echo ($pagina_actual=='calendario_profes.php')?'active bg-success shadow':''; ?>">
  <i class="bi bi-calendar3 me-2"></i> Calendario
</a>
```

### Integración en el panel principal
```html
<div class="col-6 col-md-4 col-xl-3">
    <a href="calendario_profes.php" class="card-nav shadow-sm">
        <div class="icon-wrapper"><i class="bi bi-calendar3"></i></div>
        <span class="card-title-nav">Calendario</span>
        <span class="card-desc d-none d-sm-block">Asistencia docente</span>
    </a>
</div>
```

---

## 5️⃣ 🎁 Modo Oscuro (Sorpresa)

**Archivo:** `Assets/dark-mode.js`  
No requiere dependencias. Se activa en **todas** las páginas con un botón flotante.

### Integración
Añade **una sola línea** al final de cada página PHP que quieras que tenga modo oscuro
(justo antes del `</body>`):

```html
<script src="../Assets/dark-mode.js"></script>
```

Si la página está en la raíz de `JIS/` (como `Login.php`):
```html
<script src="Assets/dark-mode.js"></script>
```

El botón aparece automáticamente, recuerda la preferencia del usuario por **365 días**
usando una cookie y no interfiere con ningún otro script.

---

## ✅ Checklist de instalación rápida

- [ ] Copiar archivos a sus carpetas correspondientes
- [ ] `composer require phpmailer/phpmailer` (para email)
- [ ] `composer require phpoffice/phpspreadsheet` (para Excel)
- [ ] Configurar SMTP en `notificar_acudiente.php`
- [ ] Añadir llamada a `enviarNotificacionSalida()` en `guardar_salida_est.php`
- [ ] Añadir links en `sidebar.php` y en `index2.php`
- [ ] Añadir `<script src="../Assets/dark-mode.js"></script>` en cada página
- [ ] Probar exportación PDF y Excel desde `reportes.php`

---

*Generado para el proyecto JIS – Colegio San Francisco de Asís (COSFA)*
